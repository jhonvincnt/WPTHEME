<?php
require('includes/includes.php');
require('includes/nav-menu.php');
require('includes/enable.php');
require('includes/pagenation.php');
require('includes/post.php');