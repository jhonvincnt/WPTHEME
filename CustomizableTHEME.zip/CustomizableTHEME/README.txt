/*
Theme Name: PurpleBUG THEME - A SIMPLE CUSTOMIZABLE THEME
Author URI: jhonvincentsoso@gmail.com 
Author:  jhonvincentsoso
Version: 1.0
Description: A simple customizable WordPress template, color customization function, category navigate to the other section, responsive design.
If you wish to modify the color of your content, go to your website settings and click the APPEARANCE button, then pick MY THEME, which is PurpleBUG THEME, and click customise.

*/
