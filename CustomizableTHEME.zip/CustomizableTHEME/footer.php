<footer class="page-footer">
    <div class="container">
      <div class="row">
        <div class="col-sm-12 py-2">
          <center>
          <p id="copyright">&copy; 2022 <a href="#">Just another wordpress</a>. All rights reserved</p>
           <div class="social-icon">
        <a href="http://youtube.com/username"><img margin="5px"src="<?php echo get_template_directory_uri()."/assets/icon/youtube_icon.png"; ?>"  width="60" height="60" alt="Youtube">
        <a href="http://instagram.com/username"><img margin="5px"src="<?php echo get_template_directory_uri()."/assets/icon/instagram_icon.png"; ?>"  width="30" height="30" alt="Instagram"></a><a href="http://facebook.com/username"><img margin="10px"src="<?php echo get_template_directory_uri()."/assets/icon/facebook_icon.png"; ?>" width="30" height="30" alt="Facebook"></a><a href="http://twitter.com" ><img margin="5px"src="<?php echo get_template_directory_uri()."/assets/icon/twittericon.png"; ?>" width="30" height="30" alt="Twitter"></a></div></div>
        </center>
        </div>
      </div>
    </div> 
  </footer> 
<?php
    wp_footer();
?>
</body>
</html>